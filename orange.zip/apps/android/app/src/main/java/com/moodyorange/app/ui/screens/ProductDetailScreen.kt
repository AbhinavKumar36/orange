package com.moodyorange.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.moodyorange.app.data.model.Product
import com.moodyorange.app.ui.components.ErrorStateView
import com.moodyorange.app.ui.components.LoadingStateView
import com.moodyorange.app.ui.components.ProductImage
import com.moodyorange.app.ui.theme.BorderMuted
import com.moodyorange.app.ui.theme.CardBackground
import com.moodyorange.app.ui.theme.CreamBackground
import com.moodyorange.app.ui.theme.InStockBg
import com.moodyorange.app.ui.theme.InStockGreen
import com.moodyorange.app.ui.theme.OrangeLight
import com.moodyorange.app.ui.theme.OrangePrimary
import com.moodyorange.app.ui.theme.OutOfStockBg
import com.moodyorange.app.ui.theme.OutOfStockRed
import com.moodyorange.app.ui.theme.SurfaceVariant
import com.moodyorange.app.ui.theme.TextMuted
import com.moodyorange.app.ui.theme.TextPrimary
import com.moodyorange.app.ui.theme.TextSecondary
import com.moodyorange.app.ui.theme.VegGreen
import com.moodyorange.app.ui.viewmodel.CatalogViewModel
import com.moodyorange.app.ui.viewmodel.ProductDetailUiState
import com.moodyorange.app.util.CurrencyFormatter

@Composable
fun ProductDetailScreen(
    productIdOrSlug: String,
    viewModel: CatalogViewModel,
    onBackClick: () -> Unit,
    onAddToCart: (Product) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val detailState by viewModel.productDetailState.collectAsState()

    LaunchedEffect(productIdOrSlug) {
        viewModel.loadProductDetail(productIdOrSlug)
    }

    when (val state = detailState) {
        is ProductDetailUiState.Loading, ProductDetailUiState.Idle -> {
            Column(
                modifier = modifier
                    .fillMaxSize()
                    .background(CreamBackground)
            ) {
                DetailTopBar(
                    title = "Loading...",
                    subtitle = "Boutique Catalog",
                    onBackClick = onBackClick
                )
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    LoadingStateView(message = "Fetching confection details...")
                }
            }
        }
        is ProductDetailUiState.NotFound -> {
            Column(
                modifier = modifier
                    .fillMaxSize()
                    .background(CreamBackground)
            ) {
                DetailTopBar(
                    title = "Not Found",
                    subtitle = "Boutique Catalog",
                    onBackClick = onBackClick
                )
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(OrangeLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "🍰", fontSize = 26.sp)
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Confection Not Found",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "The requested product is no longer available in the boutique catalog.",
                        fontSize = 14.sp,
                        color = TextMuted,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = onBackClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = OrangePrimary,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(text = "Back to Catalog", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        is ProductDetailUiState.Error -> {
            Column(
                modifier = modifier
                    .fillMaxSize()
                    .background(CreamBackground)
            ) {
                DetailTopBar(
                    title = "Error",
                    subtitle = "Boutique Catalog",
                    onBackClick = onBackClick
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    ErrorStateView(
                        message = state.message,
                        onRetry = { viewModel.loadProductDetail(productIdOrSlug, force = true) }
                    )
                }
            }
        }
        is ProductDetailUiState.Success -> {
            ProductDetailContent(
                product = state.product,
                onBackClick = onBackClick,
                onAddToCart = onAddToCart,
                modifier = modifier
            )
        }
    }
}

@Composable
private fun DetailTopBar(
    title: String,
    subtitle: String,
    onBackClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardBackground)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(OrangeLight)
                .clickable(onClick = onBackClick),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "←",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = OrangePrimary
            )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column {
            Text(
                text = title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                maxLines = 1
            )
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = TextSecondary
            )
        }
    }
}

@Composable
private fun ProductDetailContent(
    product: Product,
    onBackClick: () -> Unit,
    onAddToCart: (Product) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CreamBackground)
    ) {
        // 1. Top Bar with Back Button
        DetailTopBar(
            title = product.name,
            subtitle = product.categoryName,
            onBackClick = onBackClick
        )

        // 2. Scrollable Product Details Content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(20.dp)
        ) {
            // Hero Image Area with Coil loading & fallback placeholder
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, BorderMuted, RoundedCornerShape(20.dp))
            ) {
                ProductImage(
                    imageUrl = product.imageUrl,
                    categorySlug = product.categorySlug,
                    contentDescription = product.name,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Badges row: Veg indicator & Category & Availability
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (product.isVeg) {
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .border(1.5.dp, VegGreen, RoundedCornerShape(3.dp))
                                .background(CardBackground),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(VegGreen)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Vegetarian",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = VegGreen
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(OrangeLight)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = product.categoryName,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = OrangePrimary
                        )
                    }
                }

                // In Stock vs Out of stock
                if (product.isInStock) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(InStockBg)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "In Stock",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = InStockGreen
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(OutOfStockBg)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "Currently Unavailable",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = OutOfStockRed
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Product Title
            Text(
                text = product.name,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Authoritative Formatted Price in INR
            Text(
                text = product.formattedPrice,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = OrangePrimary
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Description Section
            if (!product.description.isNullOrBlank()) {
                Text(
                    text = "About this confection",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = product.description,
                    fontSize = 14.sp,
                    color = TextSecondary,
                    lineHeight = 22.sp
                )
                Spacer(modifier = Modifier.height(18.dp))
            }

            // Specs Card: Preparation time and Allergens
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(CardBackground)
                    .border(1.dp, BorderMuted, RoundedCornerShape(14.dp))
                    .padding(16.dp)
            ) {
                // Prep time
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "⏱️", fontSize = 16.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Preparation Time",
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                        Text(
                            text = "${product.prepTimeMinutes} minutes fresh craft",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Allergens
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "🌾", fontSize = 16.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Allergen Information",
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                        val allergenText = if (product.allergens.isNotEmpty()) {
                            "Contains: " + product.allergens.joinToString(", ")
                        } else {
                            "No major allergens declared"
                        }
                        Text(
                            text = allergenText,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Phase 5 Add to Shopping Bag Action
            val isInStock = product.isInStock
            val priceText = CurrencyFormatter.formatPaiseToInr(product.basePrice)
            Button(
                onClick = { onAddToCart(product) },
                enabled = isInStock,
                colors = ButtonDefaults.buttonColors(
                    containerColor = OrangePrimary,
                    contentColor = Color.White,
                    disabledContainerColor = SurfaceVariant,
                    disabledContentColor = TextMuted
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Text(
                    text = if (isInStock) "Add to Shopping Bag • $priceText" else "Temporarily Unavailable",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
