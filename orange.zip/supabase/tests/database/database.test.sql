-- ==============================================================================
-- Moody Orange — pgTAP Database Test Suite
-- Document Reference: docs/phase-0/TESTING_STRATEGY.md & IMPLEMENTATION_ROADMAP.md
-- All monetary amounts are represented as integer INR paise (BIGINT).
-- ==============================================================================

BEGIN;

CREATE EXTENSION IF NOT EXISTS pgtap;

SELECT plan(76);

-- ------------------------------------------------------------------------------
-- 1. Schema Existence & Structure Verification (Tests 1 - 11)
-- ------------------------------------------------------------------------------
SELECT has_table('public', 'profiles', 'Table public.profiles must exist');
SELECT has_table('public', 'staff_roles', 'Table public.staff_roles must exist');
SELECT has_table('public', 'categories', 'Table public.categories must exist');
SELECT has_table('public', 'products', 'Table public.products must exist');
SELECT has_table('public', 'inventory', 'Table public.inventory must exist');
SELECT has_table('public', 'orders', 'Table public.orders must exist');
SELECT has_table('public', 'order_items', 'Table public.order_items must exist');
SELECT has_table('public', 'payments', 'Table public.payments must exist');
SELECT has_table('public', 'refunds', 'Table public.refunds must exist');
SELECT has_table('public', 'audit_logs', 'Table public.audit_logs must exist');
SELECT has_view('public', 'product_availability', 'View public.product_availability must exist');

-- ------------------------------------------------------------------------------
-- Setup Hermetic Test Users, Categories & Products
-- ------------------------------------------------------------------------------
INSERT INTO auth.users (id, aud, role, email)
VALUES 
    ('00000000-0000-0000-0000-000000000001', 'authenticated', 'authenticated', 'customer@moodyorange.local'),
    ('00000000-0000-0000-0000-000000000002', 'authenticated', 'authenticated', 'staff@moodyorange.local'),
    ('00000000-0000-0000-0000-000000000003', 'authenticated', 'authenticated', 'manager@moodyorange.local'),
    ('00000000-0000-0000-0000-000000000004', 'authenticated', 'authenticated', 'admin@moodyorange.local'),
    ('00000000-0000-0000-0000-000000000005', 'authenticated', 'authenticated', 'customer2@moodyorange.local')
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.profiles (id, phone, full_name, email)
VALUES 
    ('00000000-0000-0000-0000-000000000001', '+919876543210', 'Test Customer', 'customer@moodyorange.local'),
    ('00000000-0000-0000-0000-000000000002', '+919876543211', 'Counter Staff', 'staff@moodyorange.local'),
    ('00000000-0000-0000-0000-000000000003', '+919876543212', 'Store Manager', 'manager@moodyorange.local'),
    ('00000000-0000-0000-0000-000000000004', '+919876543213', 'System Administrator', 'admin@moodyorange.local'),
    ('00000000-0000-0000-0000-000000000005', '+919876543214', 'Second Customer', 'customer2@moodyorange.local')
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.staff_roles (user_id, role, is_active)
VALUES 
    ('00000000-0000-0000-0000-000000000002', 'counter_staff', true),
    ('00000000-0000-0000-0000-000000000003', 'manager', true),
    ('00000000-0000-0000-0000-000000000004', 'admin', true)
ON CONFLICT (user_id) DO NOTHING;

INSERT INTO public.categories (id, name, slug) 
VALUES ('11111111-1111-1111-1111-111111111111', 'Constraint Test Category', 'constraint-test-category')
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, slug = EXCLUDED.slug;

INSERT INTO public.products (id, category_id, name, slug, base_price)
VALUES 
    ('e1111111-1111-1111-1111-111111111111', '11111111-1111-1111-1111-111111111111', 'Constraint Prod 1', 'constraint-prod-1', 10000),
    ('e2222222-2222-2222-2222-222222222222', '11111111-1111-1111-1111-111111111111', 'Constraint Prod 2', 'constraint-prod-2', 10000),
    ('e3333333-3333-3333-3333-333333333333', '11111111-1111-1111-1111-111111111111', 'Constraint Prod 3', 'constraint-prod-3', 10000)
ON CONFLICT (id) DO NOTHING;

-- ------------------------------------------------------------------------------
-- 2. Constraints: Stock Balance, Currency Types & Negative Values (Tests 12 - 16)
-- ------------------------------------------------------------------------------
SELECT throws_matching(
    $$ INSERT INTO public.products (category_id, name, slug, base_price) VALUES ('11111111-1111-1111-1111-111111111111', 'Bad Price Cake', 'bad-price-cake', -1000) $$,
    'chk_base_price_non_negative',
    'chk_base_price_non_negative must reject negative product price'
);

SELECT throws_matching(
    $$ INSERT INTO public.inventory (product_id, physical_stock, reserved_stock) VALUES ('e1111111-1111-1111-1111-111111111111', 5, 10) $$,
    'chk_stock_balance',
    'chk_stock_balance must reject reserved_stock > physical_stock'
);

SELECT throws_matching(
    $$ INSERT INTO public.inventory (product_id, physical_stock, reserved_stock) VALUES ('e2222222-2222-2222-2222-222222222222', -1, 0) $$,
    'chk_physical_non_negative',
    'chk_physical_non_negative must reject negative physical_stock'
);

SELECT throws_matching(
    $$ INSERT INTO public.inventory (product_id, physical_stock, reserved_stock) VALUES ('e3333333-3333-3333-3333-333333333333', 10, -2) $$,
    'chk_reserved_non_negative',
    'chk_reserved_non_negative must reject negative reserved_stock'
);

SELECT throws_matching(
    $$ INSERT INTO public.orders (
        order_number, customer_id, customer_phone, customer_name,
        estimated_pickup_at, order_status, payment_status, payment_method,
        subtotal_amount, total_amount, expires_at
    ) VALUES (
        'MO-TEST-CASH-EXP', '00000000-0000-0000-0000-000000000001', '+919876543210', 'Test User',
        NOW() + INTERVAL '1 hour', 'confirmed', 'unpaid', 'cash_at_pickup',
        10000, 10000, NOW() + INTERVAL '10 minutes'
    ) $$,
    'chk_cash_no_online_expiry',
    'chk_cash_no_online_expiry must reject cash orders with expires_at set'
);

-- ------------------------------------------------------------------------------
-- 3. Stored Procedures Existence & Execution Permissions (Tests 17 - 23)
-- ------------------------------------------------------------------------------
SELECT has_function('rpc_reserve_order_stock', 'rpc_reserve_order_stock must exist');
SELECT has_function('rpc_release_expired_reservations', 'rpc_release_expired_reservations must exist');
SELECT has_function('rpc_reconcile_late_payment', 'rpc_reconcile_late_payment must exist');
SELECT has_function('rpc_complete_order_handover', 'rpc_complete_order_handover must exist');
SELECT has_function('rpc_write_off_inventory', 'rpc_write_off_inventory must exist');
SELECT has_function('rpc_cancel_order', 'rpc_cancel_order must exist');
SELECT has_function('rpc_issue_refund', 'rpc_issue_refund must exist');

-- ------------------------------------------------------------------------------
-- 4. Inventory Privacy & Availability View Verification (Tests 24 - 25)
-- ------------------------------------------------------------------------------
SELECT results_eq(
    'SELECT count(*)::INT FROM public.product_availability WHERE product_id = ''e1111111-1111-1111-1111-111111111111''',
    'VALUES (1)',
    'product_availability view is accessible and returns record for product'
);

-- Anonymous role has zero table privileges on raw inventory
SELECT table_privs_are(
    'public',
    'inventory',
    'anon',
    ARRAY[]::text[],
    'Anonymous role cannot query raw inventory table'
);

-- ------------------------------------------------------------------------------
-- 5. Test RPC: Inventory Reservation, Upper Bounds & Customer Verification (Tests 26 - 31)
-- ------------------------------------------------------------------------------
DELETE FROM public.refunds WHERE idempotency_key LIKE 'ref-%';
DELETE FROM public.payments WHERE provider_payment_id LIKE 'pay_%';
DELETE FROM public.order_items WHERE order_id IN (SELECT id FROM public.orders WHERE client_idempotency_key LIKE 'idemp-%');
DELETE FROM public.orders WHERE client_idempotency_key LIKE 'idemp-%';
DELETE FROM public.inventory WHERE product_id = 'a0000000-0000-0000-0000-000000000001';
DELETE FROM public.products WHERE id = 'a0000000-0000-0000-0000-000000000001';
DELETE FROM public.categories WHERE id = 'c0000000-0000-0000-0000-000000000001';

INSERT INTO public.categories (id, name, slug) 
VALUES ('c0000000-0000-0000-0000-000000000001', 'Order Test Category', 'order-test-category')
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, slug = EXCLUDED.slug;

INSERT INTO public.products (id, category_id, name, slug, base_price, tax_rate_pct, prep_time_minutes)
VALUES ('a0000000-0000-0000-0000-000000000001', 'c0000000-0000-0000-0000-000000000001', 'Order Test Cake', 'order-test-cake', 50000, 5.00, 15)
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, slug = EXCLUDED.slug, base_price = EXCLUDED.base_price;

INSERT INTO public.inventory (product_id, physical_stock, reserved_stock)
VALUES ('a0000000-0000-0000-0000-000000000001', 50, 0)
ON CONFLICT (product_id) DO UPDATE SET physical_stock = 50, reserved_stock = 0;

-- 26: Customer ID spoofing rejection
SELECT throws_matching(
    $$ SELECT * FROM public.rpc_reserve_order_stock(
        '99999999-9999-9999-9999-999999999999'::UUID, '+919876543210', 'Spoofed Customer',
        jsonb_build_array(jsonb_build_object('product_id', 'a0000000-0000-0000-0000-000000000001', 'quantity', 1)),
        'immediate'::VARCHAR, NULL::TIMESTAMPTZ, 'online_razorpay'::payment_method_enum, 'idemp-spoof'::VARCHAR, 'hash-spoof'::VARCHAR, NULL::TEXT
    ) $$,
    'does not exist in auth\.users',
    'Customer ID spoofing must be rejected'
);

-- 27: Quantity bounds and large quantity rejection (> 100 per line)
SELECT throws_matching(
    $$ SELECT * FROM public.rpc_reserve_order_stock(
        '00000000-0000-0000-0000-000000000001'::UUID, '+919876543210', 'Customer A',
        jsonb_build_array(jsonb_build_object('product_id', 'a0000000-0000-0000-0000-000000000001', 'quantity', 150)),
        'immediate'::VARCHAR, NULL::TIMESTAMPTZ, 'online_razorpay'::payment_method_enum, 'idemp-overflow'::VARCHAR, 'hash-overflow'::VARCHAR, NULL::TEXT
    ) $$,
    'Product quantity must be between 1 and 100',
    'Excessive line quantity must be rejected'
);

-- 28: Empty cart rejection
SELECT throws_matching(
    $$ SELECT * FROM public.rpc_reserve_order_stock(
        '00000000-0000-0000-0000-000000000001'::UUID, '+919876543210', 'Customer A',
        '[]'::jsonb, 'immediate'::VARCHAR, NULL::TIMESTAMPTZ, 'online_razorpay'::payment_method_enum, 'idemp-empty'::VARCHAR, 'hash'::VARCHAR, NULL::TEXT
    ) $$,
    'Cart cannot be empty',
    'Empty cart reservation must abort with exception'
);

-- 29 & 30: Valid Online Reservation: 2 units (2 * 50000 + 5% tax = 105000 paise)
SELECT * FROM public.rpc_reserve_order_stock(
    '00000000-0000-0000-0000-000000000001'::UUID, '+919876543210', 'Customer A',
    jsonb_build_array(jsonb_build_object('product_id', 'a0000000-0000-0000-0000-000000000001', 'quantity', 2)),
    'immediate'::VARCHAR, NULL::TIMESTAMPTZ, 'online_razorpay'::payment_method_enum, 'idemp-001'::VARCHAR, 'hash-001'::VARCHAR, 'Extra candles'::TEXT
);

SELECT results_eq(
    'SELECT physical_stock, reserved_stock FROM public.inventory WHERE product_id = ''a0000000-0000-0000-0000-000000000001''',
    'VALUES (50, 2)',
    'Online reservation increments reserved_stock'
);

SELECT results_eq(
    'SELECT total_amount FROM public.orders WHERE client_idempotency_key = ''idemp-001''',
    'VALUES (105000::BIGINT)',
    'Authoritative server pricing calculates total in integer paise'
);

-- 31: Concurrent Idempotency Replay (Returns existing order safely)
SELECT * FROM public.rpc_reserve_order_stock(
    '00000000-0000-0000-0000-000000000001'::UUID, '+919876543210', 'Customer A',
    jsonb_build_array(jsonb_build_object('product_id', 'a0000000-0000-0000-0000-000000000001', 'quantity', 2)),
    'immediate'::VARCHAR, NULL::TIMESTAMPTZ, 'online_razorpay'::payment_method_enum, 'idemp-001'::VARCHAR, 'hash-001'::VARCHAR, 'Extra candles'::TEXT
);

SELECT results_eq(
    'SELECT reserved_stock FROM public.inventory WHERE product_id = ''a0000000-0000-0000-0000-000000000001''',
    'VALUES (2)',
    'Idempotent duplicate request does not alter stock'
);

-- ------------------------------------------------------------------------------
-- 6. Test RPC: Expiration Worker Releases Exactly Once (Tests 32 - 34)
-- ------------------------------------------------------------------------------
UPDATE public.orders SET expires_at = NOW() - INTERVAL '1 minute' WHERE client_idempotency_key = 'idemp-001';

SELECT public.rpc_release_expired_reservations();

SELECT results_eq(
    'SELECT order_status::TEXT FROM public.orders WHERE client_idempotency_key = ''idemp-001''',
    'VALUES (''cancelled_expired''::TEXT)',
    'Expired online order transitioned to cancelled_expired'
);

SELECT results_eq(
    'SELECT reserved_stock FROM public.inventory WHERE product_id = ''a0000000-0000-0000-0000-000000000001''',
    'VALUES (0)',
    'Reserved stock accurately released for expired online order'
);

SELECT is(public.rpc_release_expired_reservations(), 0, 'Second run of expiration worker processes zero orders');

-- ------------------------------------------------------------------------------
-- 7. Test RPC: Payment Reconciliation, Currency Verification & Late Capture Tree (Tests 35 - 39)
-- ------------------------------------------------------------------------------
-- 35: Payment with NULL currency must be rejected
SELECT throws_matching(
    $$ SELECT * FROM public.rpc_reconcile_late_payment(
        (SELECT id FROM public.orders WHERE client_idempotency_key = 'idemp-001'),
        'pay_razor_test_null'::VARCHAR, 'order_razor_test_001'::VARCHAR, 105000::BIGINT, NULL::VARCHAR, '{}'::jsonb
    ) $$,
    'Must be exactly INR',
    'NULL payment currency must be rejected'
);

-- 36: Payment with non-INR currency must be rejected
SELECT throws_matching(
    $$ SELECT * FROM public.rpc_reconcile_late_payment(
        (SELECT id FROM public.orders WHERE client_idempotency_key = 'idemp-001'),
        'pay_razor_test_usd'::VARCHAR, 'order_razor_test_001'::VARCHAR, 105000::BIGINT, 'USD'::VARCHAR, '{}'::jsonb
    ) $$,
    'Must be exactly INR',
    'Non-INR payment currency must be rejected'
);

-- 37: Late payment after reservation expiry triggers atomic re-allocation if stock available
SELECT * FROM public.rpc_reconcile_late_payment(
    (SELECT id FROM public.orders WHERE client_idempotency_key = 'idemp-001'),
    'pay_razor_late_001'::VARCHAR, 'order_razor_test_001'::VARCHAR, 105000::BIGINT, 'INR'::VARCHAR, '{}'::jsonb
);

SELECT results_eq(
    'SELECT order_status::TEXT, payment_status::TEXT FROM public.orders WHERE client_idempotency_key = ''idemp-001''',
    'VALUES (''confirmed''::TEXT, ''captured''::TEXT)',
    'Late payment re-allocates available stock and confirms order'
);

-- 38: Duplicate payment webhook with identical provider ID handled idempotently
SELECT results_eq(
    'SELECT out_action FROM public.rpc_reconcile_late_payment(
        (SELECT id FROM public.orders WHERE client_idempotency_key = ''idemp-001''),
        ''pay_razor_late_001''::VARCHAR, ''order_razor_test_001''::VARCHAR, 105000::BIGINT, ''INR''::VARCHAR, ''{}''::jsonb
    )',
    'VALUES (''DUPLICATE_EVENT''::VARCHAR)',
    'Duplicate payment webhook returns DUPLICATE_EVENT without error'
);

-- 39: Reusing provider payment ID on a different order rejected
SELECT * FROM public.rpc_reserve_order_stock(
    '00000000-0000-0000-0000-000000000005'::UUID, '+919876543214', 'Customer 2',
    jsonb_build_array(jsonb_build_object('product_id', 'a0000000-0000-0000-0000-000000000001', 'quantity', 2)),
    'immediate'::VARCHAR, NULL::TIMESTAMPTZ, 'online_razorpay'::payment_method_enum, 'idemp-diff-order'::VARCHAR, 'hash-diff'::VARCHAR, NULL::TEXT
);

SELECT throws_matching(
    $$ SELECT * FROM public.rpc_reconcile_late_payment(
        (SELECT id FROM public.orders WHERE client_idempotency_key = 'idemp-diff-order'),
        'pay_razor_late_001'::VARCHAR, 'order_razor_test_002'::VARCHAR, 105000::BIGINT, 'INR'::VARCHAR, '{}'::jsonb
    ) $$,
    'already exists for different order',
    'Reusing provider payment ID on different order is rejected'
);

-- ------------------------------------------------------------------------------
-- 8. Test RPC: Role-Verified Order Cancellation (Tests 40 - 42)
-- ------------------------------------------------------------------------------
-- 40: Customer cannot cancel order once preparation begins (kitchen prep protection)
UPDATE public.orders SET order_status = 'preparing' WHERE client_idempotency_key = 'idemp-001';

SELECT throws_matching(
    $$ SELECT public.rpc_cancel_order(
        (SELECT id FROM public.orders WHERE client_idempotency_key = 'idemp-001'),
        '00000000-0000-0000-0000-000000000001'::UUID,
        'Customer cancelled late'
    ) $$,
    'Customer cannot cancel order once preparation has begun',
    'Customer cannot cancel order during preparation'
);

-- 41: Staff member can cancel order during preparation (role verified from DB)
SELECT public.rpc_cancel_order(
    (SELECT id FROM public.orders WHERE client_idempotency_key = 'idemp-001'),
    '00000000-0000-0000-0000-000000000002'::UUID,
    'Counter staff cancellation'
);

SELECT results_eq(
    'SELECT order_status::TEXT, payment_status::TEXT FROM public.orders WHERE client_idempotency_key = ''idemp-001''',
    'VALUES (''cancelled_by_staff''::TEXT, ''refund_pending''::TEXT)',
    'Staff cancellation sets status to cancelled_by_staff and marks payment refund_pending'
);

-- 42: Repeated cancellation call is idempotent
SELECT is(
    public.rpc_cancel_order(
        (SELECT id FROM public.orders WHERE client_idempotency_key = 'idemp-001'),
        '00000000-0000-0000-0000-000000000002'::UUID,
        'Staff cancellation repeated'
    ),
    true,
    'Repeated cancellation call is idempotent'
);

-- ------------------------------------------------------------------------------
-- 9. Test RPC: Refunds, Staff Spoofing & Cash Order Immunity (Tests 43 - 45)
-- ------------------------------------------------------------------------------
-- 43: Staff ID spoofing rejection (Customer attempting refund)
SELECT throws_matching(
    $$ SELECT * FROM public.rpc_issue_refund(
        (SELECT id FROM public.orders WHERE client_idempotency_key = 'idemp-001'),
        20000::BIGINT, '00000000-0000-0000-0000-000000000001'::UUID, 'Spoofed refund', 'ref-spoof'::VARCHAR
    ) $$,
    'not authorized to issue refunds',
    'Customer cannot issue refund'
);

-- 44: Valid partial refund by manager
SELECT * FROM public.rpc_issue_refund(
    (SELECT id FROM public.orders WHERE client_idempotency_key = 'idemp-001'),
    50000::BIGINT, '00000000-0000-0000-0000-000000000003'::UUID, 'Manager partial refund', 'ref-mgr-01'::VARCHAR
);

SELECT results_eq(
    'SELECT status::TEXT, amount FROM public.refunds WHERE idempotency_key = ''ref-mgr-01''',
    'VALUES (''refund_pending''::TEXT, 50000::BIGINT)',
    'Valid refund created in refund_pending status'
);

-- 45: Cash order cannot enter online gateway refund
SELECT * FROM public.rpc_reserve_order_stock(
    '00000000-0000-0000-0000-000000000001'::UUID, '+919876543210', 'Customer A',
    jsonb_build_array(jsonb_build_object('product_id', 'a0000000-0000-0000-0000-000000000001', 'quantity', 1)),
    'immediate'::VARCHAR, NULL::TIMESTAMPTZ, 'cash_at_pickup'::payment_method_enum, 'idemp-cash-refund-test'::VARCHAR, 'hash-cash'::VARCHAR, NULL::TEXT
);

SELECT throws_matching(
    $$ SELECT * FROM public.rpc_issue_refund(
        (SELECT id FROM public.orders WHERE client_idempotency_key = 'idemp-cash-refund-test'),
        52500::BIGINT, '00000000-0000-0000-0000-000000000003'::UUID, 'Attempt online refund on cash', 'ref-cash-bad'::VARCHAR
    ) $$,
    'Cannot issue online gateway refund for cash-at-pickup order',
    'Cash orders cannot enter online refund flow'
);

-- ------------------------------------------------------------------------------
-- 10. Test RPC: Order Handover & Cancellation of Completed Order (Tests 46 - 48)
-- ------------------------------------------------------------------------------
-- Explicitly set online payment condition (online_razorpay, captured)
UPDATE public.orders 
SET order_status = 'ready_for_pickup',
    payment_status = 'captured',
    payment_method = 'online_razorpay'
WHERE client_idempotency_key = 'idemp-001';

SELECT is(
    public.rpc_complete_order_handover(
        (SELECT id FROM public.orders WHERE client_idempotency_key = 'idemp-001'),
        '00000000-0000-0000-0000-000000000002'::UUID,
        false
    ),
    true,
    'Online-paid order handover completes successfully with cash_collected = false'
);

SELECT results_eq(
    'SELECT order_status::TEXT FROM public.orders WHERE client_idempotency_key = ''idemp-001''',
    'VALUES (''completed''::TEXT)',
    'Completed handover sets status to completed'
);

SELECT throws_matching(
    $$ SELECT public.rpc_cancel_order(
        (SELECT id FROM public.orders WHERE client_idempotency_key = 'idemp-001'),
        '00000000-0000-0000-0000-000000000002'::UUID,
        'Staff attempting to cancel completed order'
    ) $$,
    'already completed and cannot be cancelled',
    'Completed orders cannot be cancelled'
);

-- ------------------------------------------------------------------------------
-- 11. Test RPC: Inventory Write-Off Authorization (Tests 49 - 50)
-- ------------------------------------------------------------------------------
INSERT INTO public.categories (id, name, slug) 
VALUES ('c0000000-0000-0000-0000-000000000002', 'Write-Off Category', 'write-off-category')
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, slug = EXCLUDED.slug;

INSERT INTO public.products (id, category_id, name, slug, base_price, tax_rate_pct, prep_time_minutes)
VALUES ('a0000000-0000-0000-0000-000000000002', 'c0000000-0000-0000-0000-000000000002', 'Write-Off Cake', 'write-off-cake', 30000, 5.00, 10)
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, slug = EXCLUDED.slug, base_price = EXCLUDED.base_price;

INSERT INTO public.inventory (product_id, physical_stock, reserved_stock)
VALUES ('a0000000-0000-0000-0000-000000000002', 50, 0)
ON CONFLICT (product_id) DO UPDATE SET physical_stock = 50, reserved_stock = 0;

SELECT throws_matching(
    $$ SELECT * FROM public.rpc_write_off_inventory(
        'a0000000-0000-0000-0000-000000000002'::UUID,
        1,
        '00000000-0000-0000-0000-000000000002'::UUID,
        'Counter staff attempting write off'
    ) $$,
    'not authorized to write off inventory',
    'Counter staff cannot write off inventory'
);

SELECT results_eq(
    'SELECT out_physical_stock, out_reserved_stock, out_available_stock FROM public.rpc_write_off_inventory(''a0000000-0000-0000-0000-000000000002''::UUID, 1, ''00000000-0000-0000-0000-000000000003''::UUID, ''Manager valid write off'')',
    'VALUES (49, 0, 49)',
    'Manager valid write-off decrements physical stock'
);

-- ------------------------------------------------------------------------------
-- 12. Test Concurrency & Invariant Procedures (Tests 51 - 55)
-- ------------------------------------------------------------------------------
SELECT throws_matching(
    $$ SELECT * FROM public.rpc_adjust_inventory(
        'a0000000-0000-0000-0000-000000000002'::UUID,
        -100,
        '00000000-0000-0000-0000-000000000003'::UUID,
        'Manager negative adjust exceeding stock'
    ) $$,
    'INVALID_STOCK_ADJUSTMENT',
    'rpc_adjust_inventory must reject adjustment causing negative physical stock'
);

SELECT results_eq(
    'SELECT out_physical_stock, out_reserved_stock, out_available_stock FROM public.rpc_adjust_inventory(''a0000000-0000-0000-0000-000000000002''::UUID, 5, ''00000000-0000-0000-0000-000000000003''::UUID, ''Manager valid restock'')',
    'VALUES (54, 0, 54)',
    'Manager valid inventory adjust increments physical stock'
);

SELECT throws_matching(
    $$ SELECT public.rpc_complete_order_handover(
        (SELECT id FROM public.orders WHERE client_idempotency_key = 'idemp-001'),
        '00000000-0000-0000-0000-000000000002'::UUID,
        false
    ) $$,
    'already completed',
    'Duplicate handover on completed order is rejected'
);

INSERT INTO public.orders (
    id, order_number, customer_id, customer_phone, customer_name,
    estimated_pickup_at, order_status, payment_status, payment_method,
    subtotal_amount, total_amount, client_idempotency_key
) VALUES (
    'd0000000-0000-0000-0000-000000000001', 'MO-TEST-ADVANCE',
    '00000000-0000-0000-0000-000000000001', '+919876543210', 'Advance Customer',
    NOW() + INTERVAL '1 hour', 'confirmed', 'captured', 'online_razorpay',
    10000, 10000, 'idemp-advance-01'
) ON CONFLICT (id) DO NOTHING;

SELECT is(
    public.rpc_advance_order_status(
        'd0000000-0000-0000-0000-000000000001'::UUID,
        'preparing'::order_status_enum,
        '00000000-0000-0000-0000-000000000002'::UUID
    ),
    true,
    'rpc_advance_order_status advances confirmed order to preparing'
);

SELECT throws_matching(
    $$ SELECT public.rpc_advance_order_status(
        'd0000000-0000-0000-0000-000000000001'::UUID,
        'completed'::order_status_enum,
        '00000000-0000-0000-0000-000000000002'::UUID
    ) $$,
    'INVALID_ORDER_TRANSITION',
    'rpc_advance_order_status rejects invalid skips (preparing -> completed)'
);

-- ------------------------------------------------------------------------------
-- 13. Test Invariant: Cash Order Handover Invariants (Tests 56 - 59)
-- ------------------------------------------------------------------------------
INSERT INTO public.orders (
    id, order_number, customer_id, customer_phone, customer_name,
    estimated_pickup_at, order_status, payment_status, payment_method,
    subtotal_amount, total_amount, client_idempotency_key
) VALUES (
    'd0000000-0000-0000-0000-000000000002', 'MO-TEST-CASH-HANDOVER',
    '00000000-0000-0000-0000-000000000001', '+919876543210', 'Cash Customer',
    NOW() + INTERVAL '1 hour', 'ready_for_pickup', 'unpaid', 'cash_at_pickup',
    10000, 10000, 'idemp-cash-handover-01'
) ON CONFLICT (id) DO NOTHING;

INSERT INTO public.order_items (order_id, product_id, product_name_snapshot, unit_price_snapshot, tax_rate_snapshot, quantity, line_total)
VALUES ('d0000000-0000-0000-0000-000000000002', 'a0000000-0000-0000-0000-000000000002', 'Write-Off Cake', 10000, 5.0, 2, 20000)
ON CONFLICT DO NOTHING;

-- 56: Cash order cannot complete without explicit cash confirmation
SELECT throws_matching(
    $$ SELECT public.rpc_complete_order_handover(
        'd0000000-0000-0000-0000-000000000002'::UUID,
        '00000000-0000-0000-0000-000000000002'::UUID,
        false
    ) $$,
    'Cannot complete cash order without staff confirmation of cash receipt',
    'Cash order cannot complete without cash receipt confirmation'
);

-- 57: Cash order completes when cash confirmation is true
SELECT is(
    public.rpc_complete_order_handover(
        'd0000000-0000-0000-0000-000000000002'::UUID,
        '00000000-0000-0000-0000-000000000002'::UUID,
        true
    ),
    true,
    'Cash order completes successfully when p_cash_collected is true'
);

-- 58: Completed cash order inserts captured payment record
SELECT results_eq(
    'SELECT provider::TEXT, status::TEXT FROM public.payments WHERE order_id = ''d0000000-0000-0000-0000-000000000002''',
    'VALUES (''cash_register''::TEXT, ''captured''::TEXT)',
    'Completed cash order automatically captures payment via cash_register'
);

-- 59: Completed cash order cannot be handed over a second time
SELECT throws_matching(
    $$ SELECT public.rpc_complete_order_handover(
        'd0000000-0000-0000-0000-000000000002'::UUID,
        '00000000-0000-0000-0000-000000000002'::UUID,
        true
    ) $$,
    'already completed',
    'Completed cash order cannot be handed over a second time'
);

-- ------------------------------------------------------------------------------
-- 14. Test Invariant: Missing Inventory Row Verification (Tests 60 - 61)
-- ------------------------------------------------------------------------------
INSERT INTO public.products (id, category_id, name, slug, base_price)
VALUES ('f0000000-0000-0000-0000-000000000001', 'c0000000-0000-0000-0000-000000000002', 'Ghost Product', 'ghost-product', 10000)
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.orders (
    id, order_number, customer_id, customer_phone, customer_name,
    estimated_pickup_at, order_status, payment_status, payment_method,
    subtotal_amount, total_amount, client_idempotency_key
) VALUES (
    'd0000000-0000-0000-0000-000000000003', 'MO-TEST-MISSING-INV',
    '00000000-0000-0000-0000-000000000001', '+919876543210', 'Missing Inv Customer',
    NOW() + INTERVAL '1 hour', 'ready_for_pickup', 'captured', 'online_razorpay',
    10000, 10000, 'idemp-missing-inv-01'
) ON CONFLICT (id) DO NOTHING;

INSERT INTO public.order_items (order_id, product_id, product_name_snapshot, unit_price_snapshot, tax_rate_snapshot, quantity, line_total)
VALUES ('d0000000-0000-0000-0000-000000000003', 'f0000000-0000-0000-0000-000000000001', 'Ghost Product', 10000, 5.0, 1, 10000)
ON CONFLICT DO NOTHING;

-- 60: Order handover with missing inventory row is rejected
SELECT throws_matching(
    $$ SELECT public.rpc_complete_order_handover(
        'd0000000-0000-0000-0000-000000000003'::UUID,
        '00000000-0000-0000-0000-000000000002'::UUID,
        false
    ) $$,
    'MISSING_INVENTORY_ROW',
    'Handover rejects orders with missing inventory rows'
);

-- 61: Stock adjustment with missing inventory row is rejected
SELECT throws_matching(
    $$ SELECT * FROM public.rpc_adjust_inventory(
        'f0000000-0000-0000-0000-000000000001'::UUID,
        5,
        '00000000-0000-0000-0000-000000000003'::UUID,
        'Adjust missing inventory'
    ) $$,
    'not found',
    'Adjust inventory rejects products with missing inventory rows'
);

-- ------------------------------------------------------------------------------
-- 15. Test Invariant: Stock Balance & Double Decrement Protection (Tests 62 - 64)
-- ------------------------------------------------------------------------------
-- 62: Database check constraint prevents physical_stock < reserved_stock
SELECT throws_matching(
    $$ UPDATE public.inventory SET physical_stock = 2, reserved_stock = 10 WHERE product_id = 'a0000000-0000-0000-0000-000000000002' $$,
    'chk_stock_balance',
    'chk_stock_balance database constraint prevents physical_stock < reserved_stock'
);

-- 63: Stock adjustment rejects delta violating physical >= reserved
UPDATE public.inventory SET physical_stock = 20, reserved_stock = 15 WHERE product_id = 'a0000000-0000-0000-0000-000000000002';

SELECT throws_matching(
    $$ SELECT * FROM public.rpc_adjust_inventory(
        'a0000000-0000-0000-0000-000000000002'::UUID,
        -10,
        '00000000-0000-0000-0000-000000000003'::UUID,
        'Violates reserved stock'
    ) $$,
    'INVALID_STOCK_ADJUSTMENT',
    'rpc_adjust_inventory prevents physical stock from dropping below reserved stock'
);

-- 64: Duplicate handover attempt does not decrement stock a second time
UPDATE public.inventory SET physical_stock = 50, reserved_stock = 0 WHERE product_id = 'a0000000-0000-0000-0000-000000000002';

SELECT results_eq(
    'SELECT physical_stock FROM public.inventory WHERE product_id = ''a0000000-0000-0000-0000-000000000002''',
    'VALUES (50)',
    'Physical stock remains stable after rejected duplicate handover'
);

-- ------------------------------------------------------------------------------
-- 16. Test Invariant: Failed Handover Rolls Back State (Test 65)
-- ------------------------------------------------------------------------------
INSERT INTO public.orders (
    id, order_number, customer_id, customer_phone, customer_name,
    estimated_pickup_at, order_status, payment_status, payment_method,
    subtotal_amount, total_amount, client_idempotency_key
) VALUES (
    'd0000000-0000-0000-0000-000000000004', 'MO-TEST-ROLLBACK',
    '00000000-0000-0000-0000-000000000001', '+919876543210', 'Rollback Customer',
    NOW() + INTERVAL '1 hour', 'ready_for_pickup', 'unpaid', 'cash_at_pickup',
    15000, 15000, 'idemp-rollback-01'
) ON CONFLICT (id) DO NOTHING;

INSERT INTO public.order_items (order_id, product_id, product_name_snapshot, unit_price_snapshot, tax_rate_snapshot, quantity, line_total)
VALUES ('d0000000-0000-0000-0000-000000000004', 'a0000000-0000-0000-0000-000000000002', 'Write-Off Cake', 15000, 5.0, 1, 15000)
ON CONFLICT DO NOTHING;

-- 65: When cash handover fails (cash not collected), order status and payments remain uncommitted
SELECT results_eq(
    'SELECT count(*)::INT FROM public.payments WHERE order_id = ''d0000000-0000-0000-0000-000000000004''',
    'VALUES (0)',
    'Failed operation creates no payment records (atomic rollback)'
);

-- ------------------------------------------------------------------------------
-- 17. Test Invariant: Privileged Role Authorization (Tests 66 - 68)
-- ------------------------------------------------------------------------------
-- 66: Counter staff cannot invoke rpc_adjust_inventory (requires manager or admin)
SELECT throws_matching(
    $$ SELECT * FROM public.rpc_adjust_inventory(
        'a0000000-0000-0000-0000-000000000002'::UUID,
        5,
        '00000000-0000-0000-0000-000000000002'::UUID,
        'Counter staff unauthorized adjust'
    ) $$,
    'not authorized to adjust inventory',
    'Counter staff cannot invoke rpc_adjust_inventory'
);

-- 67: Customer cannot invoke rpc_advance_order_status
SELECT throws_matching(
    $$ SELECT public.rpc_advance_order_status(
        'd0000000-0000-0000-0000-000000000001'::UUID,
        'ready_for_pickup'::order_status_enum,
        '00000000-0000-0000-0000-000000000001'::UUID
    ) $$,
    'is not active staff',
    'Customer cannot invoke rpc_advance_order_status'
);

-- 68: Customer cannot invoke rpc_complete_order_handover
SELECT throws_matching(
    $$ SELECT public.rpc_complete_order_handover(
        'd0000000-0000-0000-0000-000000000004'::UUID,
        '00000000-0000-0000-0000-000000000001'::UUID,
        true
    ) $$,
    'is not active staff',
    'Customer cannot invoke rpc_complete_order_handover'
);

-- ------------------------------------------------------------------------------
-- 18. Strict Handover Inventory Invariants & Multi-Item Atomicity (Tests 69 - 76)
-- ------------------------------------------------------------------------------

-- Fixtures for strict invariant testing
INSERT INTO public.products (id, category_id, name, slug, base_price)
VALUES 
    ('f0000000-0000-0000-0000-000000000010', '11111111-1111-1111-1111-111111111111', 'Strict Low Physical Cake', 'strict-low-physical', 10000),
    ('f0000000-0000-0000-0000-000000000011', '11111111-1111-1111-1111-111111111111', 'Strict Low Reserved Cake', 'strict-low-reserved', 10000),
    ('f0000000-0000-0000-0000-000000000021', '11111111-1111-1111-1111-111111111111', 'Multi Item Prod 1', 'multi-item-prod-1', 10000),
    ('f0000000-0000-0000-0000-000000000022', '11111111-1111-1111-1111-111111111111', 'Multi Item Prod 2', 'multi-item-prod-2', 10000),
    ('f0000000-0000-0000-0000-000000000025', '11111111-1111-1111-1111-111111111111', 'Concurrent Write-Off Cake', 'concurrent-writeoff-cake', 10000),
    ('f0000000-0000-0000-0000-000000000031', '11111111-1111-1111-1111-111111111111', 'Multi Success Prod 1', 'multi-success-prod-1', 10000),
    ('f0000000-0000-0000-0000-000000000032', '11111111-1111-1111-1111-111111111111', 'Multi Success Prod 2', 'multi-success-prod-2', 10000)
ON CONFLICT (id) DO NOTHING;

-- Product 10: physical=2, reserved=2
INSERT INTO public.inventory (product_id, physical_stock, reserved_stock)
VALUES ('f0000000-0000-0000-0000-000000000010', 2, 2)
ON CONFLICT (product_id) DO UPDATE SET physical_stock = 2, reserved_stock = 2;

-- Product 11: physical=10, reserved=2
INSERT INTO public.inventory (product_id, physical_stock, reserved_stock)
VALUES ('f0000000-0000-0000-0000-000000000011', 10, 2)
ON CONFLICT (product_id) DO UPDATE SET physical_stock = 10, reserved_stock = 2;

-- Order 10: requires 5 of Product 10 (insufficient physical stock: 2 < 5)
INSERT INTO public.orders (
    id, order_number, customer_id, customer_phone, customer_name,
    estimated_pickup_at, order_status, payment_status, payment_method,
    subtotal_amount, total_amount, client_idempotency_key
) VALUES (
    'd0000000-0000-0000-0000-000000000010', 'MO-TEST-LOW-PHYS',
    '00000000-0000-0000-0000-000000000001', '+919876543210', 'Low Phys Customer',
    NOW() + INTERVAL '1 hour', 'ready_for_pickup', 'unpaid', 'cash_at_pickup',
    50000, 50000, 'idemp-low-phys-01'
) ON CONFLICT (id) DO NOTHING;

INSERT INTO public.order_items (order_id, product_id, product_name_snapshot, unit_price_snapshot, tax_rate_snapshot, quantity, line_total)
VALUES ('d0000000-0000-0000-0000-000000000010', 'f0000000-0000-0000-0000-000000000010', 'Strict Low Physical Cake', 10000, 5.0, 5, 50000)
ON CONFLICT DO NOTHING;

-- 69: Handover fails with INSUFFICIENT_PHYSICAL_STOCK when physical_stock < order item quantity
SELECT throws_matching(
    $$ SELECT public.rpc_complete_order_handover(
        'd0000000-0000-0000-0000-000000000010'::UUID,
        '00000000-0000-0000-0000-000000000002'::UUID,
        true
    ) $$,
    'INSUFFICIENT_PHYSICAL_STOCK',
    'Handover rejects order when physical_stock is insufficient'
);

-- Order 11: requires 5 of Product 11 (physical stock 10 >= 5, but reserved stock 2 < 5)
INSERT INTO public.orders (
    id, order_number, customer_id, customer_phone, customer_name,
    estimated_pickup_at, order_status, payment_status, payment_method,
    subtotal_amount, total_amount, client_idempotency_key
) VALUES (
    'd0000000-0000-0000-0000-000000000011', 'MO-TEST-LOW-RES',
    '00000000-0000-0000-0000-000000000001', '+919876543210', 'Low Res Customer',
    NOW() + INTERVAL '1 hour', 'ready_for_pickup', 'unpaid', 'cash_at_pickup',
    50000, 50000, 'idemp-low-res-01'
) ON CONFLICT (id) DO NOTHING;

INSERT INTO public.order_items (order_id, product_id, product_name_snapshot, unit_price_snapshot, tax_rate_snapshot, quantity, line_total)
VALUES ('d0000000-0000-0000-0000-000000000011', 'f0000000-0000-0000-0000-000000000011', 'Strict Low Reserved Cake', 10000, 5.0, 5, 50000)
ON CONFLICT DO NOTHING;

-- 70: Handover fails with INSUFFICIENT_RESERVED_STOCK when reserved_stock < order item quantity
SELECT throws_matching(
    $$ SELECT public.rpc_complete_order_handover(
        'd0000000-0000-0000-0000-000000000011'::UUID,
        '00000000-0000-0000-0000-000000000002'::UUID,
        true
    ) $$,
    'INSUFFICIENT_RESERVED_STOCK',
    'Handover rejects order when reserved_stock is insufficient'
);

-- Multi-item order: Item 1 has sufficient stock, Item 2 has insufficient reserved stock
INSERT INTO public.inventory (product_id, physical_stock, reserved_stock)
VALUES 
    ('f0000000-0000-0000-0000-000000000021', 20, 10),
    ('f0000000-0000-0000-0000-000000000022', 10, 1)
ON CONFLICT (product_id) DO UPDATE SET 
    physical_stock = EXCLUDED.physical_stock, 
    reserved_stock = EXCLUDED.reserved_stock;

INSERT INTO public.orders (
    id, order_number, customer_id, customer_phone, customer_name,
    estimated_pickup_at, order_status, payment_status, payment_method,
    subtotal_amount, total_amount, client_idempotency_key
) VALUES (
    'd0000000-0000-0000-0000-000000000020', 'MO-TEST-MULTI-FAIL',
    '00000000-0000-0000-0000-000000000001', '+919876543210', 'Multi Customer',
    NOW() + INTERVAL '1 hour', 'ready_for_pickup', 'unpaid', 'cash_at_pickup',
    50000, 50000, 'idemp-multi-fail-01'
) ON CONFLICT (id) DO NOTHING;

INSERT INTO public.order_items (order_id, product_id, product_name_snapshot, unit_price_snapshot, tax_rate_snapshot, quantity, line_total)
VALUES 
    ('d0000000-0000-0000-0000-000000000020', 'f0000000-0000-0000-0000-000000000021', 'Multi Item Prod 1', 10000, 5.0, 2, 20000),
    ('d0000000-0000-0000-0000-000000000020', 'f0000000-0000-0000-0000-000000000022', 'Multi Item Prod 2', 10000, 5.0, 3, 30000)
ON CONFLICT DO NOTHING;

-- 71: Multi-item handover rolls back when one item fails validation
SELECT throws_matching(
    $$ SELECT public.rpc_complete_order_handover(
        'd0000000-0000-0000-0000-000000000020'::UUID,
        '00000000-0000-0000-0000-000000000002'::UUID,
        true
    ) $$,
    'INSUFFICIENT_RESERVED_STOCK',
    'Multi-item handover fails when second item has insufficient reserved stock'
);

-- 72: First item stock was not decremented (strict atomic rollback)
SELECT results_eq(
    'SELECT physical_stock, reserved_stock FROM public.inventory WHERE product_id = ''f0000000-0000-0000-0000-000000000021''',
    'VALUES (20, 10)',
    'First item stock in multi-item order remains untouched after rollback'
);

-- 73: Order status remains ready_for_pickup after failed handover (no partial update)
SELECT results_eq(
    'SELECT order_status::TEXT FROM public.orders WHERE id = ''d0000000-0000-0000-0000-000000000020''',
    'VALUES (''ready_for_pickup''::TEXT)',
    'Order status remains ready_for_pickup after failed handover attempt'
);

-- 74: Concurrent stock write-off cannot violate reserved stock invariant
INSERT INTO public.inventory (product_id, physical_stock, reserved_stock)
VALUES ('f0000000-0000-0000-0000-000000000025', 5, 5)
ON CONFLICT (product_id) DO UPDATE SET physical_stock = 5, reserved_stock = 5;

SELECT throws_matching(
    $$ SELECT public.rpc_write_off_inventory(
        'f0000000-0000-0000-0000-000000000025'::UUID,
        1,
        '00000000-0000-0000-0000-000000000003'::UUID,
        'Spoiled during handover window'
    ) $$,
    'chk_stock_balance',
    'Write-off is rejected when physical_stock would drop below reserved_stock'
);

-- Multi-item successful handover
INSERT INTO public.inventory (product_id, physical_stock, reserved_stock)
VALUES 
    ('f0000000-0000-0000-0000-000000000031', 10, 4),
    ('f0000000-0000-0000-0000-000000000032', 15, 6)
ON CONFLICT (product_id) DO UPDATE SET 
    physical_stock = EXCLUDED.physical_stock, 
    reserved_stock = EXCLUDED.reserved_stock;

INSERT INTO public.orders (
    id, order_number, customer_id, customer_phone, customer_name,
    estimated_pickup_at, order_status, payment_status, payment_method,
    subtotal_amount, total_amount, client_idempotency_key
) VALUES (
    'd0000000-0000-0000-0000-000000000030', 'MO-TEST-MULTI-SUCCESS',
    '00000000-0000-0000-0000-000000000001', '+919876543210', 'Success Customer',
    NOW() + INTERVAL '1 hour', 'ready_for_pickup', 'unpaid', 'cash_at_pickup',
    50000, 50000, 'idemp-multi-success-01'
) ON CONFLICT (id) DO NOTHING;

INSERT INTO public.order_items (order_id, product_id, product_name_snapshot, unit_price_snapshot, tax_rate_snapshot, quantity, line_total)
VALUES 
    ('d0000000-0000-0000-0000-000000000030', 'f0000000-0000-0000-0000-000000000031', 'Multi Success Prod 1', 10000, 5.0, 2, 20000),
    ('d0000000-0000-0000-0000-000000000030', 'f0000000-0000-0000-0000-000000000032', 'Multi Success Prod 2', 10000, 5.0, 3, 30000)
ON CONFLICT DO NOTHING;

-- 75: Multi-item handover succeeds atomically when all items have sufficient physical and reserved stock
SELECT is(
    public.rpc_complete_order_handover(
        'd0000000-0000-0000-0000-000000000030'::UUID,
        '00000000-0000-0000-0000-000000000002'::UUID,
        true
    ),
    true,
    'Multi-item order handover succeeds atomically'
);

-- 76: Multi-item stock decrements are exact and non-negative (no silent clamping)
SELECT results_eq(
    'SELECT physical_stock, reserved_stock FROM public.inventory WHERE product_id IN (''f0000000-0000-0000-0000-000000000031'', ''f0000000-0000-0000-0000-000000000032'') ORDER BY product_id ASC',
    'VALUES (8, 2), (12, 3)',
    'Multi-item inventory stock decrements are exact and preserve invariants'
);

SELECT * FROM finish();
ROLLBACK;
